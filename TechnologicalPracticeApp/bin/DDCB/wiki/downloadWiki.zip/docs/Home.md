**Project Description**

DropDownCheckBoxes is an ASP.NET server control directly inheriting from standard ASP.NET CheckBoxList control. It supports parent's API (except members responsible for rendering and styling) and in most cases CheckBoxList control can be simply replaced with DropDownCheckBoxes without any need to change data binding code, event handlers etc..

In normal state the control is displayed as a select (DropDownList) control. Clicking the expand button (arrow) shows a list with check boxes. When the selcetion is completed by a user a postback event may occur in following cases: 
- on leaving the control (clicking outside it, ) when property 'AutoPostBack = true'  
- clicking 'OK' button in the drop down list (if the corresponding option is active for the control, property 'UseButtons = true') 
- During any postback from other page controls (property 'AutoPostBack = false')

The control can be styled using CSS and custom properties. Also in the assembly you'll find ExtendedRequiredFieldValidator component which allows doing client & server side validation against CheckBoxList and DropDownCheckBoxes controls.

The control was tested in FF, Chrome, Safari, Opera (latest version as of May 2011) and IE 8. 

It supports both synchronous and asynchronous ASP.NET postback models (can work within UpdatePanel). The current version of the control is built for .NET 3.5 but there's no problem with using it with ASP.NET 4.0. If needed the control source code can be recompiled for other target framework (2.0, 4.0) with little or no pain.

The control is for ASP.NET WebForms 3.5, 4.0, not for ASP.NET MVC.

![](Home_http://download.codeplex.com/download?ProjectName=dropdowncheckboxes&DownloadId=245729)

**NOTE:** The assembly with the control also has ExtendedRequiredFieldValidator control which is capable of doing 'Is Empty' validation against CheckBoxList control, i.e. it can validate the DropDownCheckBoxes control too.

**NOTE:** If you're developing under VS 2008 and have 'Ambiguous match found' error then use <Style2> instead of <Style> tag within <asp:DropDownCheckboxes/>.

**NOTE** No support for Design Mode when editing .aspx or .ascx files (don't know how the control looks or works when the page is displayed in VS in design mode, how Property Explorer treats complex properties, etc.)

**To Proceed**

* You may download VS 2010 project with control source code and sample ASP.NET application at [http://dropdowncheckboxes.codeplex.com/releases/view/70874#DownloadId=264124](http://dropdowncheckboxes.codeplex.com/releases/view/70874#DownloadId=264124)
* You may download the assembly with the control at [http://dropdowncheckboxes.codeplex.com/releases/view/70874#DownloadId=264125](http://dropdowncheckboxes.codeplex.com/releases/view/70874#DownloadId=264125)
* Also there're blog posts about the control here [http://saplin.blogspot.com/2011/05/dropdwoncheckboxes-introduction.html](http://saplin.blogspot.com/2011/05/dropdwoncheckboxes-introduction.html) and here [http://saplin.blogspot.com/2011/05/dropdowncheckboxes-using-control.html](http://saplin.blogspot.com/2011/05/dropdowncheckboxes-using-control.html)